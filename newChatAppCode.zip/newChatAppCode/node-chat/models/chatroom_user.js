'use strict';

const models = require('../models') 

const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class chatroom_user extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {      
      chatroom_user.belongsTo(models.User,{
        foreignKey: 'user_id',
        sourceKey:'user_id'
      })
      chatroom_user.hasMany(models.unread_message,{
        foreignKey: 'chatroom_id',
        sourceKey:'chatroom_id'
      });
    }
  };
  chatroom_user.init({
    chatroom_id: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER,
    createdAt:{
      type: DataTypes.DATE,
      field: 'created_at' 
    },
    updatedAt:{
      type: DataTypes.DATE,
      field: 'updated_at' 
    }
  }, {
    sequelize,
    tableName:'chatroom_user',
    freezeTableName: true,
    modelName: 'chatroom_user',
  });
   // chatroom_user.sync({ force: true });
  return chatroom_user;
};