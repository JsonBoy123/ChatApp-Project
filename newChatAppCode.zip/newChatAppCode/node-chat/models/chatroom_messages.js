'use strict';
const models = require('../models') 

const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class chatroom_messages extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      chatroom_messages.hasOne(models.Files, {
        foreignKey: 'messageId',
        sourceKey:'id'
        
      })
      chatroom_messages.belongsTo(models.User,{
        foreignKey: 'sender_id',
        sourceKey:'sender_id'
      })
    }
  };
  chatroom_messages.init({
    chatroomId:{
      type:DataTypes.INTEGER,
      field: 'chatroom_id' 
    },
    senderId: {
      type:DataTypes.INTEGER,
      field: 'sender_id' 
    },
    message: DataTypes.TEXT,
    is_file: DataTypes.BOOLEAN,
    msg_props: DataTypes.TEXT,
    is_delete: {
      type:DataTypes.DATE,
      field: 'deleted_at' 
    },
    createdAt:{
      type: DataTypes.DATE,
      field: 'created_at' 
    },
    updatedAt:{
      type: DataTypes.DATE,
      field: 'updated_at' 
    }
  }, {
    sequelize,
    modelName: 'chatroom_messages',
  });
  return chatroom_messages;
};