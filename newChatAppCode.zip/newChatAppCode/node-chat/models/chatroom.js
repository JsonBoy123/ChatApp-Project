'use strict';
const models = require('../models') 
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class chatroom extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      chatroom.belongsTo(models.User,{
        foreignKey: 'initiator_id',
        sourceKey:'id'
      }),
      chatroom.hasMany(models.unread_message,{
        foreignKey: 'chatroom_id',
        sourceKey:'id'
      }),
      chatroom.hasMany(models.chatroom_user,{
        foreignKey: 'chatroom_id',
        sourceKey:'id'
      });
    }
  };
  chatroom.init({
    title: DataTypes.STRING,
    description: DataTypes.TEXT,
    initiator_id: DataTypes.INTEGER,
    icon: DataTypes.STRING,
    type: DataTypes.STRING,
    createdAt:{
      type: DataTypes.DATE,
      field: 'created_at' 
    },
    updatedAt:{
      type: DataTypes.DATE,
      field: 'updated_at' 
    }
  }, {
    sequelize,
    modelName: 'chatroom',
    freezeTableName: true,
    tableName:'chatrooms'
  });
  return chatroom;
};