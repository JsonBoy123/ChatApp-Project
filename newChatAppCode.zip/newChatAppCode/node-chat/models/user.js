'use strict';
const models = require('../models') 

const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // User.hasMany(models.chatroom_user)

     // User.hasMany(models.unread_message, {
     //    foreignKey: 'user_id'
     //  })
    
    }
  };
  User.init({
    name: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    remember_token: DataTypes.STRING, 
    other_pass:DataTypes.STRING,
    createdAt:{
      type: DataTypes.DATE,
      field: 'created_at' 
    },
    updatedAt:{
      type: DataTypes.DATE,
      field: 'updated_at' 
    },
    deleted_at:{
      type: DataTypes.DATE,
      field: 'deleted_at' 
    }
  }, {
    sequelize,
    modelName: 'User',
    freezeTableName: true,
    tableName:'users'
  });
  return User;
};