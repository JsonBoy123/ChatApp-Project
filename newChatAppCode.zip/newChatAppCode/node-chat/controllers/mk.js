models.chatroom.findAll({
      
    where:{id:{ [sequelize.Op.in]:
            sequelize.literal( 
            '( SELECT chatroom_id ' +
                'FROM chatroom_user ' +
               'WHERE user_id = '+id+                    
            ')'
            ) },  
            // UserId:{[sequelize.Op.not]:id}
        },
            includeIgnoreAttributes:true,
            attributes:{
                include:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] ,
            },
            //this for condition for create relation with user
             include: [{
                model: models.User,
            //     // through: {
                    attributes: ['id', 'name'],
            //      }
            //       // where: {completed: true}
                },
                {
                  model: models.unread_message,
                   where: {readAt: null,user_id:id},
                   // through: {attributes: []} ,
                    // attributes:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] 
                    
                  required: false
            //    //   // through: {
            //    //   //     attributes: ['createdAt', 'startedAt', 'finishedAt'],
            //    //      // }
                 },
                 {
                    model: models.chatroom_user,
                     where: {
                        user_id:{[sequelize.Op.not]:id}
                     },
                     include: [{
                        model: models.User,
                    //     // through: {
                            attributes: ['id', 'name'],
                    //      }
                    //       // where: {completed: true}
                        }],
                     // through: {attributes: []} ,
                      // attributes:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] 
                      
                    required: false
              //    //   // through: {
              //    //   //     attributes: ['createdAt', 'startedAt', 'finishedAt'],
              //    //      // }
                   }

                ],
                group:['chatrooms.id']//,'User.id','unread_messages.id','chatroom_users.id',"chatroom_users->User.id"]
            
    }).then((result)=>{
        // console.log(result)
        res.send({'data':result,'logUser':userData.data})    
    }).catch((error)=>{
        console.log(error)

    })