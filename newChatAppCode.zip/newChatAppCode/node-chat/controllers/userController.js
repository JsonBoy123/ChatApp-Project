var express = require('express');
var session = require('express-session');
var models  = require('../models');
var sequelize = require('sequelize');
const  jwt  =  require('jsonwebtoken');
const Op = sequelize.Op;
const path = require("path")
const multer = require("multer");
const bcrypt = require('bcrypt');
const { where } = require('sequelize');

exports.showlogin = function(req,res){
		// res.render('index')
        var data = req.session.user;

        res.send(`${JSON.stringify(req.session)}`);
    // res.send(JSON.stringify(localStorage.getItem('userClient')))
    // models.User.findAll({where:{id:req.session.user}}).then((result)=>{
    // }).catch((error)=>{
    //     res.send(req.session.user)
    // })

}

exports. login = function (req,res){
	var username = req.body.email
	var password = req.body.password

	 models.User.findAll({ where: { email: username,other_pass:password } }).then((result)=>{
       
    	userdata = result
        data = {id:result[0].id,name:result[0].name,email:result[0].email}

    	const  expiresIn  =  1440;
    	const  accessToken  =  jwt.sign({data}, 'secretkey23456444', {
      	expiresIn:  expiresIn});
    	res.cookie('auth',accessToken);
    	localStorage.setItem('token',accessToken)
        localStorage.setItem('user',JSON.stringify(data))
      
        res.json({'user' : data ,'accessToken' :accessToken})
			// });
        }).catch((error)=>{
        	console.log(error)
        });  	
}

exports.dashbosrd = function(req,res){
	console.log(req.session.User)
}

exports.chatDashboard = function(req,res,next){   
   res.render('chat',{'data':req.session,'user': req.session.user})
}

exports.getUser = function(req,res,next){

    var userData = jwt.verify(req.query.accessToken,'secretkey23456444')
        var id = userData.data.id
        var type = 'private';

        models.chatroom.findAll({
      
            where:{id:{ [sequelize.Op.in]:
                    sequelize.literal( 
                    '( SELECT chatroom_id ' +
                        'FROM chatroom_user ' +
                       'WHERE user_id = '+id+                    
                    ')'
                    ) },  
                },
                    includeIgnoreAttributes:true,                    
                     include: [{                       
                    
                        model: models.chatroom_user,
                            where: {
                            user_id:{[sequelize.Op.not]:id}
                            },
                            include: [{
                                model: models.User,
                                attributes: ['id', 'name'],
                                where:{deleted_at :null },
                            
                                required: true
                            }],                            
                            
                        // required: true
                        }
        
                        ],
                      
                    
            }).then((result)=>{
                res.send({'data':result,'logUser':userData.data})    
            }).catch((error)=>{
                console.log(error)
        
            }) 
        
}

exports.unreadCount = async(roomId,UserId)=>{
    var count = await models.unread_message.count({where:{chatroom_id:roomId,user_id:UserId,'readAt':null}}).then((res)=>{
          return res  
    }).catch((error)=>{
        res.send(error);
    })
}


exports.get_message = (req,res)=>{
    var roomId = req.body.room_id
    var skip = req.body.skip    
    var limit = req.body.limit
    var page = req.body.page
    var userData = jwt.verify(req.body.accessToken,'secretkey23456444')

    var user_id = userData.data.id

    models.chatroom_messages.findAll({
            where:{chatroomId:roomId,is_delete:null},
            limit:limit,offset:skip,
           order: [['id', 'DESC']],
           include: [
                {
                   model: models.Files,       
                },
                {
                    model: models.User,
                    attributes: ['id', 'name'],
                }
            ]
            
            
            }).then((result)=>{
                var data = {data:result,userId:localStorage.getItem('userId')}
                var data1 = readMessage(roomId,user_id)
                res.send(data)
    }).catch((error)=>{
        console.log(error)
    })
}

exports.isLogin = (req,res)=>{
    res.send('true')
}

getCurentDate = ()=>{
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let dateFull = year + "-" + month + "-" + date
    return dateFull;
}

exports.saveMessages = async(req,res,next)=>{
    // console.log(req.body.data.accessToken)
    var userData = jwt.verify(req.body.data.accessToken,'secretkey23456444')
    var dateFull = getCurentDate();

    var chatroomUser =  await getRoomUser(req.body.data.chatroom_id,req.body.data.senderId) ;  
    // console.log(chatroomUser)
    if(userData){  

        if(req.body.data.updateId ==''){
            models.chatroom_messages.create({
                chatroomId:req.body.data.chatroom_id,
                senderId:req.body.data.senderId,
                message:req.body.data.message,
                updatedAt:dateFull,
                createdAt:dateFull
            }).then((result)=>{
                // console.log(result)
                unreadMesageEntery(chatroomUser,result,req.body.data.senderId)
                res.send(result)        
            }).catch((error)=>{
                res.send(error)        
            })    
        }
        else{
            console.log('adfafdff')
            var jsonData = {"parent_id":"","sender_id":"","sender_name":"","msg":"","quoted":"","edited":'true'}
        
            models.chatroom_messages.update({
                'message':req.body.data.message,
                'msg_props':JSON.stringify(jsonData) 
            },{
                where:{id:req.body.data.updateId}
            }).then((result)=>{
                res.send('Change Successfully..')        
            }).catch((error)=>{
                res.send('Note change..')        
            })
        }
    }
    
}

unreadMesageEntery = async (chatroomUser,result,senderId)=>{
    console.log (chatroomUser)
    var dateFull = getCurentDate();
    var wait =await chatroomUser.map((user)=>{
        // console.log(user)
                models.unread_message.create({
                    chatroom_id:user.chatroom_id,
                    user_id:user.UserId,
                    message_id:result.id,
                    updatedAt:dateFull,
                    createdAt:dateFull,
                    readAt:null
                }).then((res)=>{
                    return(res)
                }).catch((err)=>{
                    return (err)
                })

            })
    // return wait;
}

exports.delete = async(req,res) =>{
    
    var id = req.params.id
  
    var fullData = getCurentDate();
    models.chatroom_messages.update(
        {'is_delete':fullData},
        {where:{id:id}}
        ).then((data)=>{
        res.send(data)
    }).catch((error)=>{
        res.send('not delete')
    })
}

exports.forwardMessage = async (req,res)=>{

    var dateFull = getCurentDate();

    var jsonData = {"parent_id":"","sender_id":"","sender_name":"","msg":"","quoted":"","edited":'',"forward":'true'}
    var chatroomUser =  getRoomUser(req.body.data.chatroom_id,req.body.data.senderI) ;                     

    
  models.chatroom_messages.create({
                        chatroomId:req.body.data.chatroom_id,
                        senderId:req.body.data.senderId,
                        message:req.body.data.message,
                        createdAt:dateFull,
                        msg_props:JSON.stringify(jsonData)
                    }).then((result)=>{
                        chatroomUser.map((user)=>{
                            models.unread_message.create({
                                chatroom_id:req.body.data.chatroom_id,
                                user_id:user.UserId,
                                message_id:result.id
                            }).then((res)=>{
                                return '1'
                            }).catch((err)=>{

                                return '0'
                            })

                        })
                    }).catch((error)=>{
                        res.send('Note change..')        
                    })
    res.send('Change Successfully..')        
}

 getRoomUser = async (roomid,senderId)=>{
    // console.log(senderId)
    var result = await models.chatroom_user.findAll({
                            where:{
                                chatroom_id:roomid
                                ,
                                UserId: {[sequelize.Op.not]: senderId}
                                }
                            }).then((result)=>{
                                return result;
                            }).catch((error)=>{
                                return error;
                            });
    return result;                          
}

readMessage = async(roomId,user_id)=>{
    // console.log(roomId,user_id)
    var fullData = getCurentDate();
    models.unread_message.update(
            {'readAt':fullData},
            {where:{chatroom_id:roomId,user_id:user_id}}
            ).then((data)=>{
            console.log ('Done')
        }).catch((error)=>{
            console.log (error)
        })
}

exports.CallReadMessage = (req,res)=>{
    readMessage(req.params.roomId)
    return 'done';
    // console.log()
}

exports.FileUpload = async(req,res)=>{
    var dateFull = getCurentDate();
    var type = {'image/png':'fa fa-picture-o','application/pdf':'fa-file-pdf-o'}
    var allIds = [] 
    var lastId = ''

    for(const[key, value] of Object.entries(req.files)){
          
        Id = await models.chatroom_messages.create({
        chatroomId:req.body.room_id,
        senderId:req.body.senderId,
        is_file:true,
        createdAt:dateFull
        }).then((result)=>{
            
            return result.id 
        }).catch((error)=>{
            res.send('Note change..')        
        })
        allIds.push(Id)

        models.Files.create({
            messageId:Id,
            file_name:value.filename,
            mime_type:value.mimetype,
            size:value.size,
            icon:'fa fa-file',
            createdAt:dateFull,
            updatedAt:dateFull
        }).then((result)=>{
            
        }).catch((error)=>{
            console.log(error)
        })
    }
                   
     res.send(allIds);
}

exports.SelectedData = async(req,res)=>{    
    
    var data = await models.chatroom_messages.findAll({
                        where:{
                            id: req.body.ids
                        },
                        include: [{
                        model: models.Files, 
                        // required: true      
                        }]          
                        
                        }).then((result)=>{
                        res.send(result)
                    }).catch((error)=>{
                        console.log(error)
                    })
}

exports.CreateUser = async (req,res)=>{
    // var haspass = bcrypt.hashSync(req.body.data.password)
    const saltRounds = 10;
    // const myPlaintextPassword = 's0/\/\P4$$w0rD';
    const someOtherPlaintextPassword = 'not_bacon';
    
    console.log(await ConvrtPassword(req.body.data.password));
    console.log('req.body.data.password')
}

ConvrtPassword = async(pass)=>{
    const someOtherPlaintextPassword = 'not_bacon';
    const saltRounds = 10;
    var haspass = await bcrypt.hash(pass, saltRounds, function(err, hash) {
        return hash
    });
}

exports.GetAllUser = (req,res)=>{
    var allIds =(req.body.conntectedUser)
    var userData = jwt.verify(req.body.accessToken,'secretkey23456444')
    var query = ''
    if(req.body.type =='group'){
        query = {[sequelize.Op.in]: allIds};
    }
    else{
        // index = allIds.findIndex(x => x === userData.data.id);
        // allIds = allIds.splice(index, 1)
        allIds.push(userData.data.id)            
        query = {[sequelize.Op.notIn]: allIds}
    }
    
    if(userData){
        models.User.findAll({where:{
                    id: query
                }
            }).then((result)=>{
            res.send(result)
        }).catch((error)=>{
            res.send(error)
        })
    }
}

exports.CreateGroup = (req,res)=>{
    var dateFull = getCurentDate();   
    var roomUser = req.body.groupUser
    roomUser.push(req.body.createrId)
    // console.log(roomUser)
    
    models.chatroom.create({
        title:req.body.groupName,
        initiator_id:req.body.createrId,
        type:'group',
        createdAt:dateFull
    }).then((result)=>{
        for(const id of roomUser){
            models.chatroom_user.create({
                chatroom_id:result.id,
                UserId:id,
                createdAt:dateFull,
                deletedAt:dateFull
            }).then((resl)=>{
                res.send('Done')
                // console.log(res.id)
            }).catch((error)=>{
                console.log(error)
            })
        }
    }).catch((error)=>{
        res.send(error)
    })
   
}

exports.AddChatroomUser=(req,res)=>{
    var dateFull = getCurentDate(); 
    var ids = [req.body.id]
    var userData = jwt.verify(req.body.accessToken,'secretkey23456444')
    ids.push(userData.data.id)

    models.chatroom.create({
        title:'new private',
        initiator_id:userData.data.id,
        type:'private',
        createdAt:dateFull
    }).then((result)=>{
        for(const id of ids){
            models.chatroom_user.create({
                chatroom_id:result.id,
                UserId:id,
                createdAt:dateFull,
                deletedAt:dateFull
            }).then((resl)=>{
                res.send('Done')
                // console.log(res.id)
            }).catch((error)=>{
                console.log(error)
            })
        }
       
    }).catch((error)=>{
        res.send(error)
    })
}





// models.chatroom.findAll({
      
//     where:{id:{ [sequelize.Op.in]:
//             sequelize.literal( 
//             '( SELECT chatroom_id ' +
//                 'FROM chatroom_user ' +
//                'WHERE user_id = '+id+                    
//             ')'
//             ) },  
//             // UserId:{[sequelize.Op.not]:id}
//         },
//             includeIgnoreAttributes:true,
//             attributes:{
//                 include:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] ,
//             },
//             //this for condition for create relation with user
//              include: [{
//                 model: models.User,
//             //     // through: {
//                     attributes: ['id', 'name'],
//             //      }
//             //       // where: {completed: true}
//                 },
//                 {
//                   model: models.unread_message,
//                    where: {readAt: null,user_id:id},
//                    // through: {attributes: []} ,
//                     // attributes:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] 
                    
//                   required: false
//             //    //   // through: {
//             //    //   //     attributes: ['createdAt', 'startedAt', 'finishedAt'],
//             //    //      // }
//                  },
//                  {
//                     model: models.chatroom_user,
//                      where: {
//                         user_id:{[sequelize.Op.not]:id}
//                      },
//                      include: [{
//                         model: models.User,
//                     //     // through: {
//                             attributes: ['id', 'name'],
//                     //      }
//                     //       // where: {completed: true}
//                         }],
//                      // through: {attributes: []} ,
//                       // attributes:[[sequelize.fn("COUNT", sequelize.col("unread_messages.id")), "count"]] 
                      
//                     required: false
//               //    //   // through: {
//               //    //   //     attributes: ['createdAt', 'startedAt', 'finishedAt'],
//               //    //      // }
//                    }

//                 ],
//                 group:['chatrooms.id']//,'User.id','unread_messages.id','chatroom_users.id',"chatroom_users->User.id"]
            
//     }).then((result)=>{
//         // console.log(result)
//         res.send({'data':result,'logUser':userData.data})    
//     }).catch((error)=>{
//         console.log(error)

//     })