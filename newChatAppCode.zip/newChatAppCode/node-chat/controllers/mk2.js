models.User.findAll({
    where:{ id : {
        [sequelize.Op.in] :
        sequelize.literal( 
        "(select user_id from chatroom_user  where chatroom_id in (select id from chatrooms where id in (select chatroom_id from chatroom_user where user_id = 52) ))"
        )}
}}).then((result)=>{
    // console.log(result)
    res.send({'data':result,'logUser':userData.data})    
}).catch((error)=>{
    console.log(error)
});