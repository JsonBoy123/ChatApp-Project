const path = require('path');
const express = require('express');
const redis = require('redis');
const session = require('express-session');
var cookieParser = require('cookie-parser');
// let RedisStore = require('connect-redis')(session);
var bodyParser = require('body-parser');
// const bcrypt = require('bcrypt');
const  jwt  =  require('jsonwebtoken');
// let redisClient = redis.createClient();
var Sequelize = require('sequelize');
var LocalStorage = require('node-localstorage').LocalStorage;
global.localStorage = new LocalStorage('./scratch');
const axios = require('axios')
// const fileUpload = require('express-fileupload');

// var cookieSession = require('cookie-session')

const http = require('http')
const socketio = require('socket.io')
const formateMessage = require('./utils/messages')
const {userJoin,getCurrentUser,userLeave,getRoomUsers} = require('./utils/users')
const indexRouter = require('./routes/index');

//Controllerrs

const UserController = require('./controllers/userController');
const models = require('./models');


var cors = require('cors');

const app = express();
app.use(cookieParser());
app.use(cors({ origin: true }));

// app.use(cors({
// 	credentials: true,
// }))

// app.use(
//   session({
//     secret: 'notsoimportantsecret', 
//      name: "secretname", 
//      resave:true,
//      saveUninitialized:true,
//      cookie: {
//       httpOnly: false,
//       secure: !true,
//       sameSite: true,
//       expires: false // Time is in miliseconds
//   },
//     store: new RedisStore({ client: redisClient,host: 'localhost', port: 3001, ttl: 86400}),   
//     resave: false
//   })
// )

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json())

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, content type, Authorization, Accept');
    next();
});

app.set('trust proxy', 1)


// app.use(cookieSession({
//   name: 'session',
//   keys: ['key1', 'key2']
// }))

// app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));

const server = http.createServer(app)
const io = socketio(server,{cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
    credentials: true
  }})
const qs = require('qs');
	
const PORT = 3001 || process.env.PORT;

const boatName = 'Mukesh'
//Static path
app.use(express.static(path.join(__dirname,'public')));


app.use('/', indexRouter);

io.on('connection',socket =>{
	
		var users =[]

	socket.on('joinRoom',(user)=>{	
			users = user
			userJoin(socket.id,user)	
			socket.join(user.selected.chatroom_id)			
	 
	})

	
	socket.on('sendMessage',async (msg) =>{
	 	io.on('error', function(){
	 	  socket.socket.reconnect();
	 	});
		//  console.log(msg)
	 	io.emit('UpdateContact','true')
	 	const user = getCurrentUser(socket.id)
	 	for (const room of socket.rooms) {
	      if (users.selected.chatroom_id == room) {
	 	 	// console.log(room);
	 		io.to(users.selected.chatroom_id ).emit('messageReceived',msg)
	      //   socket.to(room).emit("user has left", socket.id);
	       }
	    }
	 	// console.log(user)
	 	// console.log(socket.room)
	 })

	 socket.on('sendFile',function(msg){
		io.on('error', function(){
			socket.socket.reconnect();
		  });
		  console.log(msg)
		  const user = getCurrentUser(socket.id)
		  io.to(users.selected.chatroom_id ).emit('fileReceived',msg)
	
	 })

	 socket.on('edit',function(uniqueId,editmsg){
	 	io.on('error', function(){
	 	  socket.socket.reconnect();
	 	});
	 	const user = getCurrentUser(socket.id)
	 	io.to(users.selected.chatroom_id).emit('onedit',editmsg)
	 })

	 socket.on('remove',function(deleteMsg){
	 	io.on('error', function(){
	 	  socket.socket.reconnect();
	 	});
	 	
	 	const user = getCurrentUser(socket.id)
	 	io.to(users.selected.chatroom_id).emit('onDelete',deleteMsg)
	 })

	

})


// server.listen(3000,'127.0.0.1',function(){
//  server.close(function(){
//    server.listen(3000,'122.168.194.215')
//  })
// })
server.listen(PORT, () => console.log(`Server is runing on..... ${PORT}`));