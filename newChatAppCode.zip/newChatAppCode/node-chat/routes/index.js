'use strict';
var express = require('express');
var session = require('express-session') ;
var userController = require('../controllers/userController');
var Auth = require('../controllers/auth');
const  jwt  =  require('jsonwebtoken');
var multer  = require('multer');
// const upload = multer({dest : 'uploads/'});
// const uploadFile = require("../middleware/uploade");
// const _ = require('lodash');
// var FormData = require('form-data');
const fs = require('fs');
const path = require('path');



var router = express();
// global.SECRET_KEY = 'secretkey23456444';

const { withJWTAuthMiddleware } = require("express-kun");
const protectedRouter = withJWTAuthMiddleware(router, 'secretkey23456444');
// const upload = multer();

function authenticateToken(req, res, next) {
    // console.log(req.headers)
    const token = req.headers.authorization;
   
	jwt.verify(token,'secretkey23456444', (err, user) => {
      
      if (err) return res.sendStatus(403)
    	req.user = user
    	next()
   })


//   try {
//     const decodedToken = jwt.verify(token, 'secretkey23456444');
//     const userId = decodedToken.userId;
//     if (decodedToken){//req.body.userId && req.body.userId !== userId) {
//       throw 'Invalid user ID';
//     } else {
//       next();
//     }
//   } catch {
//     res.status(401).json({
//       error: new Error('Invalid request!')
//     });
 
// };




  // const authHeader = req.headers
  //  const token = authHeader && authHeader.split(' ')[1]
  //  console.log(req)
  //  if (token == null) return res.sendStatus(401)

  // 	// jwt.verify(req.session.access_token,'secretkey23456444', (err, user) => {
    
  //   if (err) return res.sendStatus(403)
  //   req.user = user
  //   next()
  // // })
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    var newdir = req.body.imagesFolder
    var dir = `./uploads/${newdir}/`;
    // console.log(dir)
    
    if (!fs.existsSync(dir)) {
      // console.log('not ')
      fs.mkdir(dir, {recursive:true}, (err)=>{
        if (err) console.log(`Error creating directory: ${err}`)
        else console.log('Directory created successfully.')
      })
    }
    cb(null, `uploads/${newdir}/`)
  },
  filename: function (req, file, cb) {
  
    cb(null, Date.now() + file.originalname)
  }
})

var upload = multer({storage:storage})



router.get('/',userController.showlogin);
router.post('/isLogin',authenticateToken, userController.isLogin);
router.post('/login',userController.login);
router.get('/dashboard',authenticateToken,userController.chatDashboard)
router.get('/chatroom_user',authenticateToken,userController.getUser)
router.post('/get_message',authenticateToken,userController.get_message)
router.post('/saveMessages',authenticateToken,userController.saveMessages)
router.get('/deleteMessages/:id',authenticateToken,userController.delete)
router.post('/forwardMessage/',authenticateToken,userController.forwardMessage)
router.get('/unreadCount/:roomId/:UserId',authenticateToken,userController.unreadCount)
router.get('/read_message/:roomId',authenticateToken,userController.CallReadMessage)

router.post('/file_upload',upload.array('fileArr',10),userController.FileUpload);
router.post('/SelectedData/',authenticateToken,userController.SelectedData);
router.post('/CreateUser',authenticateToken,userController.CreateUser);
router.post('/GetAllUser',authenticateToken,userController.GetAllUser);
router.post('/CreateGroup',authenticateToken,userController.CreateGroup);
router.post('/AddChatroomUser',authenticateToken,userController.AddChatroomUser);

module.exports = router;
