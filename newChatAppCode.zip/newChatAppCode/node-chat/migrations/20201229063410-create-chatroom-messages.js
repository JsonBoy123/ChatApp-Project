'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('chatroom_messages', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      chatroomId: {
        type: Sequelize.INTEGER,
        references: { model: 'chatrooms', key: 'id' }
      },
      senderId: {
        type: Sequelize.INTEGER,
        references: { model: 'users', key: 'id' }
      },
      message: {
        type: Sequelize.TEXT
      },
      is_file: {
        type: Sequelize.BOOLEAN
      },
      msg_props: {
        type: Sequelize.TEXT
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
      ,
      delatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
      ,
      is_delete: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('chatroom_messages');
  }
};