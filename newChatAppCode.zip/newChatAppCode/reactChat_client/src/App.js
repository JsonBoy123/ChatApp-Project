import React from 'react'
import logo from './logo.svg';
import './App.css';
import RoutedApp from './components/Router';
// import 'bootstrap/dist/css/bootstrap.min.css';

 class App extends React.Component {
   render (){
    return(
       <RoutedApp />      
      );
    
    }
}

export default App;
