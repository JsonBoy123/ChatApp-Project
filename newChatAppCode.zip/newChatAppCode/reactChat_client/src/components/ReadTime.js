import React from 'react';


export default class ReadTime extends React.Component{
    constructor(props){
        super(props)
        this.state={
            date:''
        }
    }

    async componentWillReceiveProps(prevProps){
        if(prevProps.date!=''){
            var date  = new Date(prevProps.date)  
            await this.setState({date:date.toDateString()})        
            // console.log( )
        }
    }

    render(){
        return(
            <>
                <span id="time">{this.props.type !=='replies' ? this.props.reader.name.substr(0,this.props.reader.name.indexOf(' ')) :""} {new Date(this.props.date).toDateString()}</span>
            </>
        )
    }
}