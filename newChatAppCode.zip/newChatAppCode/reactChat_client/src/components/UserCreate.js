import React,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Button , Modal} from 'react-bootstrap'
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import AccountCircle from '@material-ui/icons/AccountCircle';
import axios from 'axios';

axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');

const useStyles = makeStyles((theme) => ({
    margin: {
      margin: theme.spacing(1),
    },
  }));

export default function UserCreate(props){
     const[isopen,setisopen]= useState(props.showModel)   
    
    const closeModel = ()=>{
	    setisopen(false)
        props.closeForm()
	}

    const saveData = (event)=>{
        event.preventDefault()
        alert()
        var data = {
            first_name:event.target.first_name.value,
            last_name:event.target.last_name.value,
            email:event.target.email.value,
            password:event.target.password.value
        }
        
        axios.post('http://127.0.0.1:3001/CreateUser',{data}).then((result)=>{
            console.log(result)
        }).catch((error)=>{
            console.log(error)
        })
    }

    return (
        <>
            <Modal
            show={isopen}
            onHide={closeModel}
            backdrop="static"
            keyboard={false}
            >
                <Modal.Header closeButton>
                <Modal.Title>Create User</Modal.Title>
                </Modal.Header>
                <Modal.Body>                   
                    <div className="container">
                        <form onSubmit={saveData}>
                            <div className="row">
                                <div className="col-sm-12">
                                    <input name="first_name" className="form-control mb-3" placeholder="Enter First Name"/>
                                </div>
                                <div className="col-sm-12">
                                    <input name="last_name" className="form-control mb-3" placeholder="Enter Last Name"/>
                                </div>
                                <div className="col-sm-12">
                                    <input name="email" className="form-control mb-3" placeholder="Email"/>
                                </div>
                                <div className="col-sm-12">
                                    <input name="password" type="password" className="form-control mb-3" placeholder="Password"/>
                                </div>
                                <div className="col-sm-12">
                                <button className="btn btn-success">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>                       
                </Modal.Body>
                <Modal.Footer>
                    
                </Modal.Footer>
            </Modal>
        </>
    )
}