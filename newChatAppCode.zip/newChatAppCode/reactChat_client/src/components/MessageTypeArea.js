import React,{useState,useEffect} from 'react';
import TextMessage from './TextMessage'
import MessageTypeArea from './MessageTypeArea'
import DropZone from './DropZone'

export default function MessagesTypeArea(props){
	const [userMessage,setuserMessage] = useState([])
	const [crntUser,setcrntUser] = useState(null)
	const [update,setupdate] = useState({id:"",message:""})
	const [send_files,setsend_files] = useState(false)

	
	useEffect(()=>{
		console.log(update)
		setupdate(props.update)
	})

	const clearState = async () => {
        setuserMessage('')
        setcrntUser('')
        await setupdate({id:'',message:""})
        setsend_files(false)
    }
	
	const submitHandler = (event)=>{
		event.preventDefault()		
		var id = update.id
		 clearState()	
		props.sendmessage(event.target.message.value,id)
		// event.target.message.value = ''
		// 
		
	}

	const updateProps = (updateMessage)=>{
		setsend_files(true)
	}

	const attachment = ()=>{
		if(send_files == true){
			setsend_files(false);
		}
		else{
			setsend_files(true);
		}		
	}	

	const sendFile = (event)=>{
		event.preventDefault()
		
	}

	return (
		<>					
			<div className="message-input">
				<div className="wrap">
				{ send_files == true ? <DropZone sendFile = {props.sendFile}/> :''}
				<form onSubmit={submitHandler} >
				<input required name='message' defaultValue={update.message}  placeholder="Write your message..." />
				<i onClick={attachment} className="fa fa-paperclip attachment" aria-hidden="true"></i>
				<button className="submit"><i className="fa fa-paper-plane" aria-hidden="true"></i></button>
				</form>	
				</div>
			</div>
		</>
	);	
}