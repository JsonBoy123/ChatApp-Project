import React from 'react';
import axios from 'axios';
import openSocket from 'socket.io-client';
import ReactSession from 'react-client-session';
import SideBarContact from './SideBarContact';
import Group from './Group';
import UserCreate from './UserCreate';
import CreateGroup from './CreateGroup';
import { isConditionalExpression } from 'typescript';
import AddUser from './AddUser';

axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');

const socket = openSocket('http://localhost:3001');

export default class SideBar extends React.Component{
	constructor(props) {
      super(props);
    // console.log(props)
     // this.getData = 0this.getData.bind(this);

   	this.state = { 
   		data: [],
   		logUser:'',
		addUser:false,
		createGroup:false,
		allUser:[],
		connectedUser:[],
		newUserList:[],
		addSingleUser:false
   	};	
	
	   this.AddUserForm = this.AddUserForm.bind(this)
	   this.Close= this.Close.bind(this)
	   this.CreateGroupModel = this.CreateGroupModel.bind(this)
	   this.openSingleUsermodel = this.openSingleUsermodel.bind(this)

    }	
    componentWillReceiveProps(nextProps) {
  	
	  if (nextProps.user.length > 0 ) {		
		    var Data = []  
			nextProps.user.map((value,index)=>{
				if(value.type !='group'){
					Data.push(value.chatroom_users[0].User.id)
				}				
			})

			this.setState({ data: nextProps.user ,logUser:nextProps.logUser,connectedUser:Data});
	  }	  
	}

	totalMessage(){
		return '10';
	}

	async AddUserForm(){		
		this.setState({addUser:true});
	}

	async openSingleUsermodel(){
		var user = await this.getUserList('user');
		this.setState({addSingleUser:true,newUserList:user});
	}

	async CreateGroupModel(){		
		var user = await this.getUserList('group');
		this.setState({createGroup:true,newUserList:user});		
	}

	async getUserList(type){
		var user = await axios.post('http://127.0.0.1:3001/GetAllUser',{
						accessToken: localStorage.getItem('token'),
						conntectedUser:this.state.connectedUser,
						type:type						
					}).then((result)=>{
						return (result)					
					}).catch((error)=>{
						console.log(error)
					})
		return user;			
	}

	Close(){
		this.setState({createGroup:false,addUser:false,addSingleUser:false})
	}

    render(){
    	
		return(
			<>
				<div id="sidepanel">
			    <div id="profile">
			      <div className="wrap">
			        <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png" className="online" alt="" />
			        <p>{this.state.logUser.name}</p>
			        <i onClick={this.openSingleUsermodel} className="fa fa-user text-white expand-button" aria-hidden="true"></i>
			        
			        <div id="expanded">
			          <label for="twitter"><i className="fa fa-facebook fa-fw" aria-hidden="true"></i></label>
			          <input name="twitter" type="text" defaultValue="mikeross" />
			          <label for="twitter"><i className="fa fa-twitter fa-fw" aria-hidden="true"></i></label>
			          <input name="twitter" type="text" defaultValue="ross81" />
			          <label for="twitter"><i className="fa fa-instagram fa-fw" aria-hidden="true"></i></label>
			          <input name="twitter" type="text" defaultValue="mike.ross" />
			        </div>
			      </div>
			    </div>
			    <div id="search">
			      <label for=""><i className="fa fa-search" aria-hidden="true"></i></label>
			      <input type="text" placeholder="Search contacts..." />
			    </div>
			    <div id="contacts">
			      <ul>	
			      	{this.state.data.map((value,index)=>
					<>
					  {value.type !='group'  ? <SideBarContact chat={this.props.chat} contact = {value} index={index}/> : <Group chat={this.props.chat} contact = {value} index={index}/> }
					</>  
			      	)}		
			      </ul>
			    </div>
			    <div id="bottom-bar">
			      <button onClick={this.AddUserForm} id="addcontact"><i className="fa fa-user-plus fa-fw" aria-hidden="true"></i> <span>Add contact</span></button>
			      <button onClick={this.CreateGroupModel} id="settings"><i className="fa fa-users fa-fw" aria-hidden="true"></i> <span>Group</span></button>
			    </div>
			  </div>
			  { this.state.addUser == true ? <UserCreate showModel={this.state.addUser} closeForm={this.Close}/> : ''}
			  { this.state.createGroup == true ? <CreateGroup logUser={this.state.logUser} newUserList={this.state.newUserList} showModel={this.state.createGroup} closeForm={this.Close}/> : ''}
			  { this.state.addSingleUser == true ? <AddUser logUser={this.state.logUser} newUserList={this.state.newUserList} showModel={this.state.addSingleUser} closeForm={this.Close}/> : ''}
			</>
		);

	}

}