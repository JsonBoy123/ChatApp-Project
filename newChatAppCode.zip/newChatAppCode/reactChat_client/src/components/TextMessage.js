import React, { useState } from 'react';
import {
    ControlledMenu,
    MenuItem
} from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
import File from './File';
import ReadTime from './ReadTime';

export default class TextMessage extends React.Component {
   // const [isOpen, setOpen] = useState(false);
    //const [anchorPoint, setAnchorPoint] = useState({ x: 0, y: 0 });
    //console.log(props)
    constructor(props){
    	super(props);

    	this.state={
    		anchorPoint :{ x: 0, y: 0 },
    		setOpen:false
    	}
    }

    open = async(e) =>{
    	e.preventDefault()
    	var anchorPoint = {x:e.clientX,y:e.clientY}
    	await this.setState({anchorPoint:anchorPoint})
    	await this.setState({setOpen:true})
    	
    }

    close = async (e)=> {
    	await this.setState({setOpen:false})
    }

	edit = (id,message)=>{
		this.props.edit(id,message);
	}

    async Remove(id){
    	
    	// alert(id)
    	 
    }

    render(){
		
	    return (
			
	    	<li key={this.props.index} className={this.props.class} >
				<ReadTime date={this.props.messageDetails.dateTime} type={this.props.class} reader={this.props.messageDetails.user}/>
				<div>
					<img src="http://emilcarlsson.se/assets/mikeross.png" alt="" />
					<div className="messageContainer" onContextMenu={(e) => {this.open(e)
						// e.preventDefault();
						// setAnchorPoint({ x: e.clientX, y: e.clientY });
						// setOpen(true);
					}}>
					
					{this.props.messageDetails.type == true  ? <File file={this.props.messageDetails.file}/>:<p>{this.props.messageDetails.message}</p>}
				

						<ControlledMenu anchorPoint={this.state.anchorPoint} isOpen={this.state.setOpen}
							onClose={(e) => {this.close(e)}}>
							<MenuItem onClick={(() => this.props.remove(this.props.messageDetails.index))} >Delete</MenuItem>
							<MenuItem onClick={(() => this.edit(this.props.messageDetails.index,this.props.messageDetails.message))}>Edit</MenuItem>
							<MenuItem onClick={(()=>this.props.forward(this.props.messageDetails.message))}>Forward</MenuItem>
							{this.props.messageDetails.type === true ? <MenuItem onClick={(()=>this.props.forward(this.props.messageDetails.index))}>Download</MenuItem>:''}
						</ControlledMenu>
					</div >
				</div>
		    </li>
	    );
    }
}