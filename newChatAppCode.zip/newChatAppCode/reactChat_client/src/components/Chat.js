import React from 'react';
import SideBar from './SideBar';
import Messages from './Messages';
import axios from 'axios';
import openSocket from 'socket.io-client';
import { makeStyles } from '@material-ui/core/styles';
import { Button , Modal} from 'react-bootstrap'

const socket = openSocket('http://localhost:3001/');
// import 'bootstrap/dist/css/bootstrap.min.css';
axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');


 class Chat extends React.Component {

 	constructor(props){  
    super(props);  
    this.chatMessage = this.chatMessage.bind(this);  
    this.SendMessage = this.SendMessage.bind(this);  
    this.DeleteMessage = this.DeleteMessage.bind(this);  
    this.RemoveDeteleMessage = this.RemoveDeteleMessage.bind(this);  
    this.openModel = this.openModel.bind(this);  
    this.closeModel = this.closeModel.bind(this);  
	this.sendFile = this.sendFile.bind(this)

  	this.state = {
      	contactList: [],
      	crntUser:'',
      	messages:[],
      	roomId:'',
      	selectedUser:[],
		chatGroup:[],
      	model:{
      		isopen:false,
      	},
      	forward:{
      		message:''
      	}
       };       
  	socket.on('messageReceived',(msg)=>{
  		
  		if(msg.chatroom_id == this.state.roomId){
	 		this.pushMessage(msg) 		
  		}

  	})
	  socket.on('fileReceived',(msg)=>{
		
		msg.map((value,index)=>{
			if(value.chatroomId === this.state.roomId){				
				this.pushMessage(value) 	
			}
			
		})
	})

  	socket.on('UpdateContact',(test)=>{
  		// console.log(test)
  		this.ContactList()  		
  	})

  	socket.on('onedit',(msg)=>{
  		this.updateEditMessage(msg)  		
  	})
  	socket.on('onDelete',(msg)=>{
  		this.RemoveDeteleMessage(msg)
  	})
  	socket.on('cruentUser',function(msg){
  		// console.log(msg)
  	})
  }  

	componentDidMount(){		
		var date = new Date('2021-02-02T10:57:52.000Z')
		console.log(date.getDay())
 		this.ContactList()
	}

	async ContactList(){

		var id = localStorage.getItem('user').id
		var my = await axios.get('http://localhost:3001/chatroom_user/',{params : {'id': id,'accessToken' : localStorage.getItem('token') }}).then((res)=>{
			var data = {contactList:res.data.data,crntUser:res.data.logUser};
			return (data);
		}).catch((error)=>{
			console.log(error);
		});
		// console.log(my)
		this.setState(my)	
	}

	 chatMessage = async function(userid,room_id){

		userid.chatroom_users.map((value,key)=>{
      		socket.emit('joinRoom',{'selected':value.User,'logUser':this.state.crntUser})
	 	 	this.setState({roomId:room_id,selectedUser:value.User,chatGroup:userid});
		})

		var my = await axios.post('http://localhost:3001/get_message',{room_id:room_id,skip:0,selectedUser:userid.User,page:1,limit:10,'accessToken' : localStorage.getItem('token')}).then((result)=>{
			this.ContactList()
			return result.data.data
		}).catch((error)=>{
			window.location = '/'
		})
		// console.log(my)
		var data = []
		my.map((value,index)=>{
	  			var data1 = {
	  				message:value.message,
	  				chatroom_id:value.chatroomId,
	  				dateTime:value.createdAt,
	  				senderId:value.senderId,
	  				index:value.id,
	  				msg_type:JSON.parse(value.msg_props),
					type: value.is_file !== true ? 'text':'file',
					file : value.File,
					user:value.User
	  			}
	  			data.push(data1)
	  		})
		 data.sort((a,b)=>{
			return a.index - b.index
          })
		
             // return parseInt(b.price)  - parseInt(a.price);
		// data.sort('descending').map((value,index)=>{
		// })
		await this.setState({messages:data})
		// console.log(this.state.messages)
	}

	async SendMessage(message,updateId=''){
			
		var data = {
	   				message:message,
	   				chatroom_id:this.state.roomId,
	   				senderId:this.state.crntUser.id,
	   				// index:this.state.messages.length+1,
	   				dateTime:'2020/01/01',
	   				updateId:updateId,
					is_file:'text',
	   				accessToken : localStorage.getItem('token')
	   				}		
		// console.log(data)
		if(updateId !== ''){
			const newList = this.state.messages.map((item) => {
	      		if (item.index === updateId) {
	      			item.message=message
				socket.emit('edit',item)
	      	}	 
	      	return item;
	   	 });
		await this.setState({messages:newList})
		}
		else{
			socket.emit('sendMessage',data)	
		}
			var my = await axios.post('http://localhost:3001/saveMessages',{data}).then((result)=>{
						return result.data
					}).catch((error)=>{
						console.log(error)
					})
	}

	async pushMessage(message){
		axios.get('http://127.0.0.1:3001/read_message/'+message.chatroom_id).then((res)=>{
			// console.log(res)
		}).catch((error)=>{
			this.ContactList()
			// console.log(error)

		})
		var data = this.state.messages
		// console.log(data)
		var data1 = {
			message:message.message,
			chatroom_id:message.chatroomId,
			dateTime:message.createdAt,
			senderId:message.senderId,
			index:message.id,
			msg_type:{"parent_id":"","sender_id":"","sender_name":"","msg":"","quoted":"","edited":'true'},
		  	type: message.is_file == 'text' ? 'text':'file',
		  	file : message.File !='' ? message.File:''
		}
		
	   	data.push(data1)			
	  	await this.setState({messages:data})
	  	// return data1
	}

	async updateEditMessage(editMessage){
		// console.log(editMessage)
		// const newList = this.state.messages.map((item) => {
			// console.log(item)
	      	// 	if (item.index === editMessage.index) {
	      	// 		item.message=editMessage.message
	      	// }	 
	      	// return item;
	   	//  });
		// await this.setState({messages:newList})
		// console.log(newList)
	}

	async DeleteMessage(id){
		
		 axios.get('http://localhost:3001/deleteMessages/'+id).then((res)=>{
			//send message to websocket delete the message  
			this.state.messages.filter((message) =>{
				if( message.index === id){
					socket.emit('remove',id)
				}
			});
		}).catch((error)=>{
			console.log(error)
		})				
	}

	async RemoveDeteleMessage(id){
		var newList = this.state.messages.filter((message) => message.index !== id);
		await this.setState({messages:newList});
	}

	openModel(message){
		this.setState({forward:message});
		this.setState({isopen:true})
	}

	ForwardMessage(senderId,roomid){
		var data = {
	   				message:this.state.forward,
	   				chatroom_id:roomid,
	   				senderId:senderId,
	   				dateTime:'2020/01/01',
	   				}	
	   	var my =  axios.post('http://localhost:3001/forwardMessage',{data}).then((result)=>{
					return result.data
				}).catch((error)=>{
					console.log(error)
				})			
	}

	closeModel(){
		this.setState({isopen:false})
	}

	async sendFile(file){
		// alert('sasas')
		//  console.log(file)
		
	var data1 = await axios.post('http://localhost:3001/file_upload',file).then((result)=>{
			
 			return this.getSelectedData(result.data)
			//  console.log(result.data)
			// thiresult)
		}).catch((error)=>{
			console.log(error)
		})
		socket.emit('sendFile',data1)
		// var data = []
		// data1.map((value,index)=>{
	  	// 		var data1 = {
	  	// 			message:value.message,
	  	// 			chatroom_id:value.chatroomId,
	  	// 			dateTime:value.createdAt,
	  	// 			senderId:value.senderId,
	  	// 			index:value.id,
	  	// 			msg_type:JSON.parse(value.msg_props),
		// 			type: value.is_file == null ? 'text':'file',
		// 			file : value.File
	  	// 		}
	  	// 		data.push(data1)
	  	// 	})
		//  data.sort((a,b)=>{
		// 	return a.index - b.index
        //   })
		
        //      // return parseInt(b.price)  - parseInt(a.price);
		// // data.sort('descending').map((value,index)=>{
		// // })
		// await this.setState({messages:data})	
  	}

  async getSelectedData(ids){
	 var data =  await axios.post('http://localhost:3001/SelectedData',{'ids':ids}).then((result)=>{
				return(result.data)
			}).catch((error)=>{
				console.log(error)
			})
		return data;	
  }

   render (){

    return(

     <div id="frame">
    	<SideBar logUser = {this.state.crntUser} user={this.state.contactList} chat={this.chatMessage}/>
        <Messages 
        	logUser = {this.state.crntUser}
        	selectedUser = {this.state.selectedUser}
        	sendmessage={this.SendMessage} 
        	conversion={this.state.messages}
        	room_id = {this.state.roomId}
        	remove = {this.DeleteMessage}
        	forward = {this.openModel}
			sendFile = {this.sendFile}
			GroupCheck={this.state.chatGroup}
        	 />
    
        
	      <Modal
	        show={this.state.isopen}
	        onHide={this.closeModel}
	        backdrop="static"
	        keyboard={false}
	      >
	        <Modal.Header closeButton>
	          <Modal.Title>Forward Message</Modal.Title>
	        </Modal.Header>
	        <Modal.Body>
	           <ul>	
			      	{this.state.contactList.map((value,index)=>			      		      			      	
			      
				        <li key ={index}  className="contact ">
				          <div className="wrap" id='ModelUserImage'>
				            <span className="contact-status busy"></span>
				            <img className='mr-3' src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
				            <div className="meta">
				              <p className="name">{value.chatroom_users[0].User.name}</p>
				            </div>
				            <div id='ModelSendbtn' className='mt-2'>
				            	<button onClick={(()=>this.ForwardMessage(value.chatroom_users[0].User.id,value.chatroom_id))} className='btn btn-primary'>Send</button>
				            </div>
				          </div>				          
				        </li>			        
			      	)}		
			    </ul>
	        </Modal.Body>
	        <Modal.Footer>
	          
	        </Modal.Footer>
	      </Modal>
      </div>
      );
    
    }
}

export default Chat;

