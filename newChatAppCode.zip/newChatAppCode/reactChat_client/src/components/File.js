import React, { useState } from 'react';
import {
    ControlledMenu,
    MenuItem
} from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import SkipPreviousIcon from '@material-ui/icons/SkipPrevious';
import PlayArrowIcon from '@material-ui/icons/PlayArrow';
import SkipNextIcon from '@material-ui/icons/SkipNext';

export default class File extends React.Component {
   // const [isOpen, setOpen] = useState(false);
    //const [anchorPoint, setAnchorPoint] = useState({ x: 0, y: 0 });
    //console.log(props)
    constructor(props){
    	super(props);

    	this.state={
    		anchorPoint :{ x: 0, y: 0 },
    		setOpen:false
    	}
    }

    open = async(e) =>{
    	// console.log(this.props.messageDetails)
    	e.preventDefault()
    	var anchorPoint = {x:e.clientX,y:e.clientY}
    	await this.setState({anchorPoint:anchorPoint})
    	await this.setState({setOpen:true})
    	// console.log(anchorPoint)
    	// console.log(this.state.setOpen)
    //	props.Delete(id)
    }

    close = async (e)=> {
    	await this.setState({setOpen:false})
    }

    async Remove(id){
    	
    	// alert(id)
    	 
    }

    render(){
		console.log(this.props.file)
	    return (
            
            <>
                <div className="fileShow ">   
                    
                </div>
		    </>    
	    );
    }
}