import React from 'react';
import axios from 'axios';
import TextMessage from './TextMessage';
import MessageTypeArea from './MessageTypeArea';
import $ from "jquery"
import R from "ramda"
import InfiniteScroll from 'react-infinite-scroll-component';
import openSocket from 'socket.io-client';


const socket = openSocket('http://localhost:3001/');

const style = {
  height: 30,
  border: "1px solid green",
  margin: 6,
  padding: 8
};


export default class Messages extends React.Component{

	constructor(props){
		super(props);
		this.state = {
			userMessage:[],
			crntUser:'',
			selected:''	,
		   	page:1,
		   	skip:0,
		   	size:30,
			is_group:false,
			GroupName:'',
		   	items: Array.from({ length: 20 }),
		   	update:{id:'', message:''}		
		}
		
		// this.edit = this.edit.bind(this)
		this.sendFile = this.sendFile.bind(this)
		
	}


	async componentWillReceiveProps(prevProps) {  

		this.setState({update:{id:"",message:''}})
	  	if (prevProps.conversion) {
			  if(prevProps.GroupCheck.type =='group'){
				this.setState({is_group:true,GroupName:prevProps.GroupCheck.title});
			  }
	  		await this.setState({userMessage:prevProps.conversion,selected:prevProps.selectedUser,crntUser:prevProps.logUser},() => this.scrollToMyRef())
  			this.scrollToMyRef();  			
  	 	}	
		   	      
	}

	scrollToMyRef = () => {
		let lastMessage = document.querySelector("#list #list:last-of-type")
  	 	var window_height = $('.list').length;
	    var document_height = $('.list').height();	 
	    // alert(document_height) 
	   $('.list').animate({ scrollTop:document_height*3000},1000);	   
	  };

  fetchMoreData = async() => {
  		var skip = this.state.userMessage.length
		var newMsg = 5
		axios.post('http://localhost:3001/get_message',{room_id:this.props.room_id,skip:skip,page:1,limit:newMsg,'accessToken' : localStorage.getItem('token')}).then((result)=>{
			 	this.mergeData(result)
				//  console.log(result)	
			}).catch((error)=>{
				console.log(error)
				// window.location = '/'
		})		
		
  		// console.log(this.state.userMessage){ this.state.addUser == true ? <UserCreate showModel={this.state.addUser} closeForm={this.CloseUserForm}/> : ''}
	// if(this.state.update.id !=''){
	// 	await this.setState({update:{id:'',message:''}})
	// }	
  	// var data = {id:id , message:message}
  	// await this.setState({update:data})
  }

  DeleteUpdate(id){
  	const newList = this.state.userMessage.filter((message) => message.index !== id);
    this.setState({userMessage:newList})
  }

  async sendFile(file){
		// console.log(formData)
		file.append('room_id',this.props.room_id)
		file.append('senderId',this.props.logUser.id)
		this.props.sendFile(file)
  }

  async mergeData(result){
	var mydata  = []
	// console.log(JSON.parse(result.data.data[0].msg_props))
   result.data.data.map((value,index)=>{
			 var data2 = {
				message:value.message,
				chatroom_id:value.chatroomId,
				dateTime:value.createdAt,
				senderId:value.senderId,
				index:value.id,
				msg_type:JSON.parse(value.msg_props),
			   	type:value.is_file !== true ? 'text':'file',
				file:value.File,
				user:value.User

			 }
		 mydata.push(data2)
	 })
	 //Sort mesaqge
   mydata.sort((a,b)=>{
	   return b.index - a.index
	 })

   this.state.userMessage.map((value,index)=>{
			 var data1 = {
				 message:value.message,
				 chatroom_id:value.chatroom_id,
				 dateTime:value.dateTime,
				 senderId:value.senderId,
				 index:value.index,
				 msg_type:value.msg_props,
			     type:value.type,
				 file:value.file,
				 user:value.user

			 }
		 mydata.push(data1)
	 })
   // mydata.push.apply(result.data.data)
   // console.log(mydata)
   await this.setState({userMessage:mydata})	
  }

  render() {
	  
    return (
		<>
		<div className="content">
	    <div className="contact-profile">
	      <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
		  
			<p>{this.state.is_group == true ? this.state.GroupName:this.state.selected.name}</p>
	      
	      <div className="social-media">
	        <i className="fa fa-facebook" aria-hidden="true"></i>
	        <i className="fa fa-twitter" aria-hidden="true"></i>
	         <i className="fa fa-instagram" aria-hidden="true"></i>
	      </div>
	    </div>
	    <div id="messages" className="messages" onScroll={ this.handleScroll}>
	      <ul id="list" className='list' ref={this.chatContainer}  style={{ height: 500, overflow: "auto" }}>
		     <InfiniteScroll
	            dataLength={this.state.userMessage.length}
	            next={this.fetchMoreData}
	            hasMore={true}
	            inverse={true}
	            scrollableTarget="list"
	          >
	            {this.state.userMessage.map((value,index)=>
					<>{value.senderId == this.state.crntUser.id 
						? <TextMessage forward={this.props.forward} index={value.index}  remove={ this.props.remove} edit={this.edit} messageDetails={value} class={'replies'}/>
						: <TextMessage forward={this.props.forward} remove={this.props.remove} edit={this.edit} messageDetails={value} index={value.index} class={'sent context-menu-one'}/>}	
					</>	      		
				)}
	          </InfiniteScroll>
	      </ul>
	    </div>
	    	<MessageTypeArea sendFile = {this.sendFile} update={this.state.update}  sendmessage={this.props.sendmessage} />
	  </div>
	</>
    );
  }

	
}