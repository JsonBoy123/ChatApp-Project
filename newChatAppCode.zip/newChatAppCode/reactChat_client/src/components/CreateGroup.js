import React,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Button , Modal} from 'react-bootstrap'
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import AccountCircle from '@material-ui/icons/AccountCircle';
import axios from 'axios';

axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');
const totalId=[] 
const useStyles = makeStyles((theme) => ({
    margin: {
      margin: theme.spacing(1),
    },
  }));

export default function CreateGroup(props){
     const[isopen,setisopen]= useState(props.showModel)  
     const[userList,setUserList] = useState(props.newUserList)
     const[select,setSelect] = useState([])
     
    
    const closeModel = ()=>{
	    setisopen(false)
        props.closeForm()
	}

    const saveData = (event)=>{
        event.preventDefault()
    
        var data = {
            first_name:event.target.first_name.value,
            last_name:event.target.last_name.value,
            email:event.target.email.value,
            password:event.target.password.value
        }
        
        axios.post('http://127.0.0.1:3001/CreateUser',{data}).then((result)=>{
            console.log(result)
        }).catch((error)=>{
            console.log(error)
        })
    }

    const SelectedUser = (e,id)=>{
        // var ids = select 
        // totalId.push(id)      

        var checked = e.target.checked;
        if(checked){
            setSelect(select => [...select,id]) 
        }
        else{
            const newList = select.splice(select.indexOf(id), 1);
        }
        

    }

    const createGroup = (event)=>{
        event.preventDefault()
        var groupUser = select
        var groupName = event.target.groupName.value
        axios.post('http://127.0.0.1:3001/CreateGroup',{groupUser:groupUser,groupName:groupName,createrId:props.logUser.id}).then(async (result)=>{
            await setisopen(false)    
        }).catch((error)=>{
            console.log(error)
        })
        
        
    }

    return (
        <>
            <Modal
            show={isopen}
            onHide={closeModel}
            backdrop="static"
            keyboard={false}
            >
                <Modal.Header closeButton>
                <Modal.Title>Create Group</Modal.Title>
                </Modal.Header>
                <form onSubmit={createGroup}>
                <Modal.Body>                   
                    <div className="container">                     
                            <div class="mb-4">
                                <input class="form-control" name='groupName' placeholder="Enter Group Name"/>
                            </div>
                            <ul>	
                                {userList.data.map((value,index)=>	   
                                    <li key ={index}  className="contact ">
                                        <div className="wrap" id='ModelUserImage'>
                                            <span className="contact-status busy"></span>
                                            <img className='mr-3' src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                                            <div className="meta">
                                            <p className="name">{value.name}</p>
                                            </div>
                                            <div id='ModelSendbtn' className='mt-2'>                                    
                                                <label class="customcheck">
                                                    <input onClick={((e)=>SelectedUser(e,value.id))} type="checkbox" />
                                                    <span class="checkmark"></span>
                                                </label>       
                                            </div>
                                        </div>				          
                                    </li>			        
                                )}		
                            </ul>  
                        </div>                   
                    </Modal.Body>
                <Modal.Footer>
                    <div>
                        <button class="btn btn-success">Create</button>
                    </div>                    
                </Modal.Footer>
            </form>                      
                 
            </Modal>
        </>
    )
}