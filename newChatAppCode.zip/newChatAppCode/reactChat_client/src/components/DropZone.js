import React, { Component } from "react";
import axios from 'axios';
import { render } from "react-dom";
import 'react-dropzone-uploader/dist/styles.css'
import Dropzone from 'react-dropzone-uploader'

axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');

export default class DropZone extends Component {
  constructor(props) {
    super(props);

    this.state = {
      files: [],
    };
  }

 getUploadParams = ({ meta }) => {
  // return { url: 'https://httpbin.org/post' } 
  // console.log(meta)
}
  
  // called every time a file's `status` changes
  handleChangeStatus = ({ meta, file }, status) => { 
    // console.log( meta)
     }
  
  // receives array of files that are done uploading when submit button is clicked
  handleSubmit = (files) => {
    
    var formData =  new FormData();
    formData.append('imagesFolder','420');
    for (let key of Object.keys(files)) {
      formData.append('fileArr', files[key].file)
    }
    this.props.sendFile(formData)  
    
  }

  onPreviewDrop = (files) => {
    this.setState({
      files: this.state.files.concat(files),
    });
  }

  render() {
    const previewStyle = {
      display: 'inline',
      width: 100,
      height: 100,
    };

    return (
      <>
        <div>    
           <Dropzone
            onChangeStatus={this.handleChangeStatus}
            onSubmit={(files) => this.handleSubmit(files)}
            
            styles={{ dropzone: { minHeight: 200, maxHeight: 250 } }}
          />
       </div>

      </>
    );
  }
}
