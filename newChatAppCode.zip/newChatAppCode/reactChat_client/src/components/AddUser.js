import React,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Button , Modal} from 'react-bootstrap'
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import AccountCircle from '@material-ui/icons/AccountCircle';
import axios from 'axios';

axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');
 
const useStyles = makeStyles((theme) => ({
    margin: {
      margin: theme.spacing(1),
    },
  }));

export default function AddUser(props){
    const[isopen,setisopen]= useState(props.showModel)  
    const[userList,setUserList] = useState(props.newUserList)
    const[select,setSelect] = useState([])
     
    const closeModel = ()=>{
	    setisopen(false)
        props.closeForm()
	}    

    const AddUser = (id)=>{    
        axios.post('http://127.0.0.1:3001/AddChatroomUser',{
            id:id,
            accessToken: localStorage.getItem('token'),
        }).then(async (result)=>{
            await setisopen(false)    
            closeModel()
        }).catch((error)=>{
            console.log(error)
        })
    }

    return (
        <>
            <Modal
            show={isopen}
            onHide={closeModel}
            backdrop="static"
            keyboard={false}
            >
                <Modal.Header closeButton>
                <Modal.Title>Add User</Modal.Title>
                </Modal.Header>
                
                <Modal.Body>                   
                    <div className="container">    
                        <ul>	
                            {userList.data.map((value,index)=>	   
                                <li key ={index}  className="contact ">
                                    <div className="wrap" id='ModelUserImage'>
                                        <span className="contact-status busy"></span>
                                        <img className='mr-3' src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                                        <div className="meta">
                                        <p className="name">{value.name}</p>
                                        </div>
                                        <div id='ModelSendbtn' className='mt-2'>                                    
                                            <label className="customcheck">
                                                <button onClick={(()=>AddUser(value.id))} className="btn btn-success" >Add</button>                                                   
                                            </label>       
                                        </div>
                                    </div>				          
                                </li>			        
                            )}		
                        </ul>  
                    </div>                   
                    </Modal.Body>
                <Modal.Footer>
                                      
                </Modal.Footer>
                               
                 
            </Modal>
        </>
    )
}