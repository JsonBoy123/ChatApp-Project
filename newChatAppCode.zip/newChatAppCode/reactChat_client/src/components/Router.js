import React from 'react';
import axios from 'axios';
import { BrowserRouter, Route, Switch, Redirect,useHistory } from "react-router-dom";
import Login from './Login'
import Dashboard from './Chat'
import { checkLogin } from './Helper'



class RoutedApp extends React.Component  {
    constructor(props) {
      super(props);
      // Don't call this.setState() here!
      this.state = { status: '' };
      // this.handleClick = this.handleClick.bind(this);
    }



  render(){   

    return (
      <BrowserRouter >
        <Switch>
          <Route extact path="/dashboard" component={Dashboard} /> 
          <Route extact path="/" component={Login} />      
               
        </Switch>
      </BrowserRouter>
    );
  } 
   componentDidMount(){ 

    axios.defaults.headers.common['Authorization'] = localStorage.getItem('token');
    axios.post('http://localhost:3001/isLogin').then((res)=>{
      // alert(typeof(res.data.toString()))
          // location.href ='/dashboard'
        this.setState({status:res.data.toString()})
        }).catch((error)=>{
          this.setState({status:'false'})
          // location.href  ='/'
        });
      
    }

}

export default RoutedApp;