import axios from 'axios';

export async function checkLogin() {
    // var status = false

	axios.defaults.headers.common['Authorization'] = sessionStorage.getItem('token');
    let data = await axios.post('http://localhost:3001/isLogin').then((res)=>{
				console.log(res.data)
			}).catch((error)=>{
				console.log('false')
			});
		



	// var data =  await axios.post('http://localhost:3001/isLogin').then((res)=>{
	// 		console.log(res.data)

	// 	}).catch((error)=>{
	// 		console.log('false')
	// 	})

	 return data;	
	
}