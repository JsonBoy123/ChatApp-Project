import React from 'react'

export default class Group extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            data:[]
        }

    }

    async  componentWillMount() { 
        // console.log(this.props.contact) 	
        await this.setState({ data:this.props.contact});     
    
        }    
    

    render(){

        return(
            <>      
                <li key ={this.props.index} onClick={(()=>this.props.chat(this.state.data,this.state.data.id))} className="contact ">
                    <div className='row'>  
                                
                        <div className="wrap col-sm-10">
                            <span className="contact-status busy"></span>
                            <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                            <div className="meta">
                            <p className="name">{this.state.data.title}</p>
                            </div>
                        </div>
                    
                    <div class="unread-message col-sm-2" id="unRead5">
                        {this.props.contact.count > 0 ? <span class="badge badge-soft-danger badge-pill">{this.state.data.unread_messages.length}</span>:''}
                    </div>
                    </div>
                </li>	
            </>
        )
    }
}